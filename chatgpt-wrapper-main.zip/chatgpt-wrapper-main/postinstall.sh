#!/bin/bash
echo "Installing playwright"
playwright install